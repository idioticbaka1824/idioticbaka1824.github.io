For Windows: double-click 'mnGame.exe'.
For others, use the source code 'mnGame.py' however you like. 'spritesheet.py' will need to be in the same directory, though.
(The 'res' folder is needed in both cases.)
---------

This is a simple, defensive bullet hell-style game.

Avoid the raindrops. The longer you last, the more points you get. When your health runs out, game over.

Arrow keys to move in four directions. Z to use an umbrella, which guards against rain for awhile. Sometimes an umbrella falls from the sky, grabbing it will add to your umbrella stockpile.
X to pause, and ESC to quit anytime.

Character belongs to @Nightmargin (the creator of OneShot). This is just a silly little fangame. Have fun!

-----------
by idioticbaka1824
https://raadshaikh.github.io/